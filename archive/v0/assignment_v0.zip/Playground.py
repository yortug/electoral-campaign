from Processing import *
import numpy as np
import sys
from linkedLists import linkedLists

pp = Processing()

print('All Candidates')
print('=====================')
all_candidates = pp.readCSV('./data/HouseCandidatesDownload-20499.csv', 3)
print('First: ' + str(all_candidates[0]))
print('Last: ' + str(all_candidates[len(all_candidates)-1]))

print()

print('States & Territories: ' + str(pp.findUnique(all_candidates, 0)))

print()

print('WA Candidates (Polling)')
print('=====================')
WA_candidates = pp.readCSV('./data/HouseStateFirstPrefsByPollingPlaceDownload-20499-WA.csv', 3)
print('First: ' + str(WA_candidates[0]))
print('Last: ' + str(WA_candidates[len(WA_candidates)-1]))

print()
print('==========================================')
print()

print('Unique WA Polling Districts')
print('=====================')
WA_district_names = pp.findUnique(WA_candidates, 2)
print(WA_district_names)
print(len(WA_district_names))

print()

print('WA Brand District (first 5)')
print('=====================')
WA_brand = pp.getRowsWhere(WA_candidates, 2, 'Brand')
print(WA_brand[0:5])

print()

WA_brand_parties = pp.findUnique(WA_brand, 12)
# print(WA_brand_parties)

print()

WA_brand_Gr = pp.getRowsWhere(WA_brand, 12, 'The Greens (WA)')
# print(WA_brand_Gr)

print()

WA_brand_Gr_candidates_id = pp.findUnique(WA_brand_Gr, 5)
print(WA_brand_Gr_candidates_id[0])

WA_brand_Gr_candidates_first = pp.findUnique(WA_brand_Gr, 7)
print(WA_brand_Gr_candidates_first)

print()


print()