from Processing import *
from Region import *
import numpy as np


pp = Processing()

# reading in house candidate CSV
all_candidates = pp.readCSV('./data/HouseCandidatesDownload-20499.csv', 3)

# reading in first preference vote BY polling place CSV (state/territory specific)
# len(pp.findUnique(all_candidates, 0)) - 8 states/territory, common knowledge so will use as constant for readability
all_states = np.empty(8, dtype = object)
for i,v in enumerate(pp.findUnique(all_candidates, 0)):
	all_states[i] = pp.readCSV('./data/HouseStateFirstPrefsByPollingPlaceDownload-20499-' + str(v) + '.csv', 3)

# finding the unique state/territory 'codes'
a = pp.findUnique(all_candidates, 0)
print(a)

# finding the number of unique districts (electorates) within each state
b = np.empty(8, dtype = int)
for i,z in enumerate(all_states):
	b[i] = len(pp.findUnique(z,2))

print(b)


# creating an array of State objects, with the state 'code' as its name
# and an array of size 'number of districts' ready to fill with objects
Australia = np.empty(len(pp.findUnique(all_candidates, 0)), dtype = object)
for i,v in enumerate(Australia):
	Australia[i] = State(a[i], b[i])

# creating an array ready to be filled with the district, party and
# candidate information for each state (hence the 8x3 dimensions),
# necessary to fill the 'region classes'
state_dist_part = np.empty((8,3), dtype = object)

# don't want to talk about how long i was staring at this trying
# to wrap my head around it and get it to work

# essentially it filters through the rows of information imported
# earlier, and picks out all the unique disctricts in each state,
# and then all the unique parties in each one of those districts,
# and then all the unique candidates in each one of those parties
for i,z in enumerate(all_states):
	district_names = pp.findUnique(z, 2)
	district_parties = np.empty(len(district_names), dtype = object)
	party_candidates = np.empty(len(district_names), dtype = object)
	for j,y in enumerate(district_names):
		district_parties[j] = pp.findUnique(pp.getRowsWhere(all_states[i], 2, y), 11)
		party_candidates2 = np.empty(len(district_parties[j]), dtype = object)
		for k,x in enumerate(district_parties[j]):
			party_candidates2[k] = pp.findUnique(pp.getRowsWhere(pp.getRowsWhere(all_states[i], 2, y), 11, x), 5) 
		party_candidates[j] = party_candidates2
			
	state_dist_part[i][0] = district_names
	state_dist_part[i][1] = district_parties
	state_dist_part[i][2] = party_candidates
	

# filling the array of electorate objects for each state
for i,z in enumerate(Australia):
	z.setElectorates(state_dist_part[i][0], [len(j) for j in state_dist_part[i][1]])

print()

print(state_dist_part[0][1])

print()

print(state_dist_part[0][2])

print()

print(Australia[0].electorates[0])
print(Australia[0].electorates[1])

print()

# filling the array of party objects for each district, within each state
for i,z in enumerate(Australia):
	for j,y in enumerate(z.getElectorates()):
		y.setParties(state_dist_part[i][1][j], state_dist_part[i][2][j])

print()

print(Australia[0].electorates[0].parties[0])

print()

# filling the array of candidate objects for each party, within each
# disctrict, for each state
for i,z in enumerate(Australia):
	for j,y in enumerate(z.getElectorates()):
		for k,x in enumerate(y.getParties()):
			x.setCandidates(state_dist_part[i][2][j][k])

print()

print(Australia[0].electorates[0].parties[0].candidates[0])

print()


# the final test!
# for i in Australia:
# 	print(i)
# 	for j in i.getElectorates():
# 		print('\t ', j)
# 		for k in j.getParties():
# 			print('\t\t ', k)
# 			for x in k.getCandidates():
# 				print('\t\t\t ', x)


print()

big_len = 0
for i in all_states:
	big_len = big_len + len(i)

print()
print(big_len)

all_vote_data = np.empty(big_len, dtype = object)

t_count = 0
for i in all_states:
	for j in i:
		all_vote_data[t_count] = j
		t_count += 1

print(all_vote_data[0])

print()

for i in Australia:
	#print(i)
	for j in i.getElectorates():
		#print('\t ', j)
		for k in j.getParties():
			#print('\t\t ', k)
			for x in k.getCandidates():
				#print('\t\t\t ', x)
				for y in all_vote_data: 
					if x.getID() == y[5] and k.getPartyName() == y[11] and j.getDivName() == y[2]:
						#print('updating: ' + str(x.getID()))
						x.setState(y[0])
						x.setDivision(y[2])
						x.setParty(y[11])

						x.setFname(y[7])
						x.setLname(y[6])
						if y[9] == 'Y':
							x.setElected(True)
						else:
							x.setElected(False)
						if y[10] == 'Y':
							x.setHelected(True)
						else:
							x.setHelected(False)
						x.updateVotes(int(y[13]))



for i in Australia:
	for j in i.getElectorates():
		for k in j.getParties():
			k.setVotes()


for i in Australia:
	print(i)
	for j in i.getElectorates():
		print('\t ', j)
		for k in j.getParties():
			print('\t\t ', k)
			for x in k.getCandidates():
				print('\t\t\t ', x)


print()


pp.serialize('australia5.pickle', Australia)








