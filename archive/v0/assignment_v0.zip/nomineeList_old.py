from Processing import *
from Region import *
import textwrap


pp = Processing()


the_data = pp.unserialize('australia4.pickle')

Australia = Country('Australia', len(the_data))
Australia.setStates(the_data)

# print(Australia)
# print('==================')
# for i in Australia.getStates():
# 	print(i)
# 	for j in i.getElectorates():
# 		print('\t ', j)
# 		for k in j.getParties():
# 			print('\t\t ', k)
# 			for x in k.getCandidates():
# 				print('\t\t\t ', x)


#####

states = []
divisions = []
parties = []

print("Please select your state(s):")
for i,z in enumerate(Australia.getStates()):
	print('['+str(i+1)+']'+z.getCode()+'  ', end = '  ')

print()
selection1 = input("Selection: ").split(',')
if selection1[0] in {'a', 'A'}:
	for i in Australia.getStates():
		states.append(i.getCode())
else:
	selection1 = [int(i) for i in selection1]
	for i in selection1:
		states.append(Australia.getStates()[i-1].getCode())



print()
print(states)

for i in states:
	test = ''
	print()
	print("Please select electorate(s) from " + i + ':')
	for j,z in enumerate(Australia.findState(i).getElectorates()):
		test += '['+str(j+1)+']'+z.getDivName()+'  '
	for line in textwrap.wrap(test):
		print(line)
	selection2 = input("Selection: ").split(',')
	if selection2[0] in {'a', 'A'}:
		for k in Australia.findState(i).getElectorates():
			divisions.append(k.getDivName())
	else:
		selection2 = [int(i) for i in selection2]
		for k in selection2:
			divisions.append(Australia.findState(i).getElectorates()[k-1].getDivName())
	print()
	print(divisions)

print()



possible_parties = []

for i in states:
	x = Australia.findState(i)
	if x != None:
		for j in divisions:
			y = x.findElectorate(j)
			if y != None:
				for k in y.getParties():
					possible_parties.append(k.getPartyName())

possible_parties = list(set(possible_parties))

print("Please select your partie(s):")
for i,z in enumerate(possible_parties):
	if z == '':
		z = 'NONE'
	print('['+str(i+1)+']'+z+'  ', end = '  ')

print()


selection3 = input("Selection: ").split(',')
if selection3[0] in {'a', 'A'}:
	for i in possible_parties:
		parties.append(i)
else:
	selection3 = [int(i) for i in selection3]
	for i in selection3:
		parties.append(possible_parties[i-1])
	
print()
print(parties)
print()
print('=================================')
print()

parties = sorted(parties)

test = []

for i in states:
	x = Australia.findState(i)
	if x != None:
		for j in divisions:
			y = x.findElectorate(j)
			if y != None:
				for k in parties:
					z = y.findParty(k)
					if z != None:
						for candidate in z.getCandidates():
							test.append(candidate)

for i in test:
	print(i)

