import csv
import numpy as np
import sys
sys.path.append("../w2/")
from DSASorts import *
sys.path.append("../w4/")
from linkedLists import *
import pickle
import time


class Processing:
	def __init__(self):
		...

	def readCSV(self, path, start):
		"""
		Reads in a CSV given its relative path and the line where
		reading should begin.
		INPUT:
			path (string) - relative path to .csv file
			start (integer) - line number to start CSV reading (line 1 is first line)
		OUTPUT:
			row_array (object array) - array where each element is a row of csv
		"""
		with open(path, 'r') as csvfile: 
			data = csv.reader(csvfile)
			row_count = sum(1 for row in data)

			if not start in range(0, row_count):
				raise IndexError('CSV start reading index is out of range nrows.')

			array_length = row_count - start + 1
			row_array = np.empty(array_length, dtype = object)
			
			csvfile.seek(0)
			for i in range(start-1):
				next(data)
			for j, row in enumerate(data):
				row_array[j] = row

		return row_array

	def findUnique(self, duplicate_array, col_num):
		"""
		Finds the unique set of values across multiple elements
		of an array, given a specific 'column' index
		INPUT:
			duplicate_array (object array) - array where each element
			is a row read in from a csv
			col_num (integer) - the 'column index' which indicates
			the column within each row which is processed
		OUTPUT:
			list(set(unique_array)) - a set dtype which contains each
			unique value within all processed values
		"""
		unique_array = np.empty(len(duplicate_array), dtype = object)

		for i,r in enumerate(duplicate_array):
			unique_array[i] = r[col_num]

		a = np.array(list((set(unique_array))))
		
		return DSASorts().insertionSort(a)

	def getRowsWhere(self, some_array, col_num, to_match):
		"""
		"""
		temp = DSALinkedList()
		for r in some_array:
			if r[col_num] == to_match:
				temp.insertFirst(r)

		matched_array = np.empty(len(temp), dtype = object)

		for i,v in enumerate(temp):
			matched_array[i] = v

		return matched_array

	def serialize(self, path, obj):
		"""
		"""
		with open(path, 'wb') as data:
			pickle.dump(obj, data)

	def unserialize(self, path):
		"""
		"""
		with open(path, 'rb') as picklefile:
			obj = pickle.load(picklefile)

		return obj


class MarginalProcessing:
	def __init__(self):
		...

	def printMarginalParties(self, Australia, parties, margin):
		print(Australia)
		print('==================')
		for i in Australia.getStates():
			print(i)
			for j in i.getElectorates():
				get_votes = DSALinkedList()
				for k in j.getParties():
					get_votes.insertLast(k.getVotes())
				get_vote_pct = [(abs(l - max(get_votes)) / max(get_votes)) for l in get_votes]
				marginal_parties = DSALinkedList()
				for x,z in enumerate(get_vote_pct):
					if z == 0.0:
						marginal_parties.insertLast(x)
					elif z != 0.0 and z <= margin:
						marginal_parties.insertLast(x)
				if len(marginal_parties) == 1:
					pass
				else:
					print('\t', j)
					for p in marginal_parties:
						if j.getParties()[p].getPartyName() in parties:
							print('\t\t', j.getParties()[p])


class ResultsProcessing:
	def __init__(self):
		...

	def timer(self, mes=''):
		for i in range(101):
		    time.sleep(0.007)
		    sys.stdout.write('\t' + str(mes) + "\r%d%%" % i)
		    sys.stdout.flush()

		sys.stdout.write('\n')

	def resultsPrint(self):
		print('What would you like to do with your results?')
		print('  ' + '[1] Print your results')
		print('  ' + '[2] Save your results as CSV')
		print('  ' + '[3] Save your results as serialized file')
		print('  ' + '[q] Quit to main menu')


	def resultsMenu(self, results):
		self.resultsPrint()

		selection4 = input("Selection: ")

		if selection4 == '1':
			for i in results:
				print(i)

			print()
			self.resultsMenu(results)

		elif selection4 == '2':
			name = str(input("File name: "))

			with open(name, 'w') as csv_file:
				csv_writer = csv.writer(csv_file, delimiter=',')
				csv_writer.writerow(['State','Division','Party','Elected','hElected','CandidateID','Surname','Name','Votes'])
				for i in results:
					x = str(i).split(' | ')
					csv_writer.writerow(x)

			self.timer('writing data to csv: ')
			self.timer('dumping file: ')
			print()
			self.resultsMenu(results)


		elif selection4 == '3':
			name = str(input("File name: "))
			
			with open(name, 'wb') as data:
				pickle.dump(results, data)

			self.timer('serializing data: ')
			self.timer('dumping file: ')
			print()
			self.resultsMenu(results)

		elif selection4 == 'q':
			pass
		else:
			self.resultsMenu(results)

	def marginalResultsMenu(self, Australia, parties, margin, results):
		self.resultsPrint()

		mp = MarginalProcessing()
		selection5 = input("Selection: ")


		if selection5 == '1':
			mp.printMarginalParties(Australia, parties, margin)
			print()
			self.marginalResultsMenu(Australia, parties, margin, results)
		elif selection5 == '2':
			name = str(input("File name: "))

			with open(name, 'w') as csv_file:
				csv_writer = csv.writer(csv_file, delimiter=',')
				csv_writer.writerow(['State, Location'])
				for i in results:
					x = [str(i.getCandidates()[0].getState()) ,str(i.getCandidates()[0].getDivision())]
					csv_writer.writerow(x)

			self.timer('writing data to csv: ')
			self.timer('dumping file: ')
			print()
			self.marginalResultsMenu(Australia, parties, margin, results)
		elif selection5 == '3':
			name = str(input("File name: "))
					
			with open(name, 'wb') as data:
				pickle.dump(results, data)

			self.timer('serializing data: ')
			self.timer('dumping file: ')
			print()
			self.marginalResultsMenu(Australia, parties, margin, results)
		elif selection5 == 'q':
			pass
		else:
			self.marginalResultsMenu(Australia, parties, margin, results)




