from Processing import *
from Region import *
import textwrap
import sys
sys.path.append("../w2/")
from DSASorts import *
sys.path.append("../w4/")
from linkedLists import *

pp = Processing()


the_data = pp.unserialize('australia4.pickle')


Australia = Country('Australia', len(the_data))
Australia.setStates(the_data)

possible_parties = DSALinkedList()

for i in Australia.getStates():
	for j in i.getElectorates():
		for z in j.getParties():
			possible_parties.insertLast(z.getPartyName())

possible_parties = np.array(list(set(possible_parties))) # can't go from set-object to np-array, so have to briefly cast to Python list
possible_parties = DSASorts().insertionSort(possible_parties)


test = ''

print("Please select your party (or parties):")
for i,z in enumerate(possible_parties):
	if z == '':
		z = 'NONE'
	test += '['+str(i+1)+']'+z+'  '

for line in textwrap.wrap(test):
	print(line)

print()

parties = DSALinkedList()

selection = input("Selection: ").split(',')
if selection[0] in {'a', 'A'}:
	for i in possible_parties:
		parties.insertLast(i)
else:
	selection = [int(i) for i in selection]
	for i in selection:
		parties.insertLast(possible_parties[i-1])

print(parties)
print()


print("Please enter your margin:")
selection = input("Value: ") # check for bad numbers here
margin = float(selection)
print(margin)
print()


results = DSALinkedList()

for i in Australia.getStates():
	for j in i.getElectorates():
		get_votes = DSALinkedList()
		for k in j.getParties():
			get_votes.insertLast(k.getVotes())
		get_vote_pct = [(abs(l - max(get_votes)) / max(get_votes)) for l in get_votes]
		marginal_parties = DSALinkedList()
		for x,z in enumerate(get_vote_pct):
			if z == 0.0:
				marginal_parties.insertLast(x)
			elif z != 0.0 and z <= margin:
				marginal_parties.insertLast(x)
		if len(marginal_parties) == 1:
			pass
		else:
			for p in marginal_parties:
				if j.getParties()[p].getPartyName() in parties:
					results.insertLast(j.getParties()[p])


pp2 = ResultsProcessing()
pp2.marginalResultsMenu(Australia, parties, margin, results)

print('goodbye!')






