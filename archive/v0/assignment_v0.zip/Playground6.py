import numpy as np
import re

import sys
sys.path.append("../w2/")
from DSASorts import *
sys.path.append("../w4/")
from linkedLists import *
from DSAQueue import *
sys.path.append("../w6/")
from DSAGraph import *
sys.path.append("../w8/")
from DSAHash import *


from Processing import *
from Region import *


pp = Processing()

# print()

# # importing airport data csv
# airport_data = pp.readCSV('./data/AirportDist1.0.csv', 2)
# print(airport_data[0], 'BEFORE')

# # converting airport data times from hh:mm:ss to mins
# for i in airport_data:
# 	temp = re.findall('\d+(?=:)',i[9])
# 	i[9] = str((int(temp[0])*60) + int(temp[1]))

# print(airport_data[0], 'AFTER')

# print()

# # importing electorate data csv
# electorate_data = pp.readCSV('./data/ElectDist1.0.csv', 2)
# print(electorate_data[0], 'BEFORE')

# # getting km/h (unnecessary now but kept code because whatever)
# # and converting the SECONDS into MINUTES (accidently labelled
# # the data as minutes when it's actually seconds, oooooops)
# km_h_list = DSALinkedList()
# for i in electorate_data:
# 	if i[9] == 'NONE':
# 		pass
# 	else:
# 		i[9] = str(int(i[9]) // 60) # seconds to minutes conversion
# 		km_h_list.insertLast(int((int(i[8]) / 1000) // (int(i[9]) / 60))) # getting speed (km/h)

# # finding the total km/h (again useless info at this point)
# km_h = sum(km_h_list) / float(len(km_h_list))
# print(km_h, 'km/h')

# print(electorate_data[0], 'AFTER')

# print()

# # only taking the PLANE methods of travel from airport to airport
# # because multiple edges to the same place wasn't quite supported
# # in my Kruskal's algorithm, so I decided to make the assumption
# # that the party campaigning likely has the money to pay for flights
# # (and doesn't want to waste hours and hours driving across Australia)
# airport_data_clean = DSALinkedList()
# for z in airport_data:
# 	if z[10] == 'plane':
# 		airport_data_clean.insertLast(z)
# # these are actually the routes necessary to get OUT of the ACT
# # without these edges being included, it'd be impossible for
# # an algorithm to exit ACT (would be disconnected graph)
# airport_data_clean.insertLast(electorate_data[1]) 
# airport_data_clean.insertLast(electorate_data[2])
# airport_data_clean.insertLast(electorate_data[3])
# airport_data_clean.insertLast(electorate_data[4])

# # for i in airport_data_clean:
# # 	print(i)

# print()

# print('deleting all elements with NONE distance and NONE time because they are useless for our purpose')
# # i calculated average km/h and was going to find polar distance, to estimate time but 
# # wikipedia coordinates were junk for the electorates with missing data (hence them missing)
# for i in electorate_data:
# 	if i[9] == 'NONE':
# 		i = None
# print()

# # this was a MEL to SYD combination already had a flight value, so adding this
# # by car option would cause problems for my algorithm so just deleted it for now
# print('deleting the 5th elemenet (car route from MEL air to SYD air) because plane route already exists and it probably will cause problems')
# electorate_data[5] = None
# print('electorate_data[5] :', electorate_data[5])

# print()
# print('deleting the ACT driving routes from Canberra & Fenner to airports as they were attached to the new airport_data_clean array')

# print(electorate_data[0:7], 'BEFORE')

# # deleting these FOUR routes out of the ACT from the electorate data
# # as they were already added to my airport data (made more sense)
# electorate_data[1] = None
# electorate_data[2] = None
# electorate_data[3] = None
# electorate_data[4] = None

# print(electorate_data[0:7], 'AFTER')

print()

airport_data_clean = pp.unserialize('airport_dist_clean.pickle')
electorate_data = pp.unserialize('electorate_dist_clean.pickle')

print()

# importing the user's data
marginal_locations = pp.readCSV('marginaltest.csv', 1)


# from the user's marginal electorates find the unique
# set of states, because you only need to add the airports
# which are required to connect these states
temp = np.empty(len(marginal_locations), dtype=object)
for i,z in enumerate(marginal_locations):
	temp[i] = z[0]
unique_states = set(temp)


# once we find the unique set of states necessary for the campaign
# we must then find all the connections required to travel between
# these states; that means all the airport vertices
airport_list = DSALinkedList()
for row in airport_data_clean:
	if row[0] in unique_states and row[4] in unique_states: # if from_State and to_State are part of the unique set of states
		airport_list.insertLast(row[1]) # add their from_Location
		airport_list.insertLast(row[5]) # add their to_Location
airport_vertices = set(airport_list) # our airport vertices are the unique set of to/from locations state-to-state


# we now have the vertices which connect all the required states
# so we can start to build our campaign trail; we do this by
# first creating an empty graph data structure
campaign_trail = DSAGraph()

# next we must populate this empty graph, with all the required
# airport(s), and their connecting airports - this implements
# the underlying 'web' in our graph that makes state-to-state
# travel possible (all necessary states are connected)

# adding each unique airport vertex we found previously to the graph
for location in airport_vertices:
	campaign_trail.addVertex(location)

# adding any edges that connect these airport locations to one another
for row in airport_data_clean:
	if row[1] in airport_vertices and row[5] in airport_vertices and row[10] == 'plane': # if to/from are part of the airport set (and type=plane)
		campaign_trail.addEdge2(row[1], row[5], np.array([row[8], row[9], row[10]]), False)
		# addEdge2(SOURCE, DESTINATION, VALUE=[distance (meteres), time (mins), type (plane/car)], DIRECTED?=True/Flase)


# now that the states are connected by airports, we have
# to make sure all the marginal electorates (within each
# state) are also connected to one another too 

# these required electorates are dictated by the user's CSV 
# file which should have been created by them after they
# selected a PARTY(or more) and a MARGIN in part3 of the
# assignment (data imported in as 'marginal_locations')

marginal_list = DSALinkedList()
for row in marginal_locations:
	marginal_list.insertLast(row[1])
marginal_vertices = set(marginal_list)




# adding each unique marginal electorate to the graph
for location in marginal_vertices:
	campaign_trail.addVertex(location)

# creating the set of all locations; including electorates AND airports
all_locations = marginal_vertices.union(airport_vertices)


# adding any edges which connect an electorate to any other electorate
# OR connect to their own state's airport (hence why we made union set)
for row in electorate_data:
	if row == None:
		pass
	else:
		if row[1] in all_locations and row[5] in all_locations: # if to/from are contained in the full set of unique locations
			campaign_trail.addEdge2(row[1], row[5], np.array([row[8], row[9], row[10]]), False)
			# addEdge2(SOURCE, DESTINATION, VALUE=[distance (meteres), time (mins), type (plane/car)], DIRECTED?=True/Flase)


###########################################################
# we now have our FULL CAMPAIGN TRAIL; including:         #
###########################################################
# 1. all the airports required to get to each state where #
# there's at least one marginal seat            		  #
# 2. all the edges connecting these states/airports 	  #
# (flights for every connection, except in/out of ACT)	  #
# 3. all the marginal electorates specified by the user   #
# 4. all the edges connecting the marginal electorates    #
# not just to one another within their state, but also    #
# to their state's airport 								  #
###########################################################

# but now we must work on finding the most optimal route through
# this campaign trail i.e. the minimum spanning tree




# we start this process by of course finding this minimum spanning
# tree by using Kruskal's Algorithm; here the input is '1' because
# if you can remember our edges' values were [distance, time, type]
# and we of course want to MINIMISE the FIRST element of this array
# i.e. we want to minimise time - THUS we input '1' into the method

min_spanning_tree = campaign_trail.kruskalsAlgorithm(1) 

# this results in a sub-graph of our 'full campaign graph,'
# representing only the edges which connect all our campaign
# stops (and airports) in the minimum amount of time...
# ... now we have the minimum spanning tree, but how 
# do we go about travelling through this tree, and what's 
# our estimated total travel time???

# first we create an empty linked list to store the names of all our labels
edge_list = DSALinkedList()
# it's important to note that a label here is in the string format of:
# str(str(from_Location) + str(to_Location)) i.e. "Perth AirportDarwin Airport"
# but the edge itself is UNDIRECTED meaning in this case it represents not
# just Perth TO Darwin, but also Darwin TO Perth - this will come into play later


# next we create a hash table which will store each edge's data,
# with the key being its label - this makes accessing the time needed
# to travel along each edge quite trivial, especially when you're only
# given the to_Vertex and from_Vertex (as is the result of a DFS later)
edge_hash = DSAHashTable(100)


for edge in min_spanning_tree.getEdges(): # for each edge in our minimum spanning 'tree' (graph)
	edge_hash.put(edge.getLabel(), edge) # hash the edge-object with its label as the key
	edge_list.insertLast(edge.getLabel()) # add its label to the linked list of all edges


print()

for i in min_spanning_tree.getVertices():
	print(i)

print()

# now that we have all our information it's really just a matter of
# traversing this tree in some way that we hit every single vertex,
# and of course every single edge connecting these vertices; a depth
# first search is a simple way of doing this which has already been
# implemented in one of our pracs (but functionality was extended here)


# user makes a choice as to where they'll begin their travels from
# this acts as the starting point for a depth first search
choice = 'Batman'

# as our graph stores vertices and edges seperately, and the depth
# first search ONLY returns the VERTICES as they're met in the graph,
# this means we will have to store the vertex and edge data in seperate
# queues (as they are first-in-first-out), then we can just dequeue
# each queue one at a time to get our required itinerary
# i.e. electorate/airport -> EDGE -> electorate/airport -> EDGE -> etc, etc

# create an empty queue to store the (in-order of the dfs) vertices
vertex_queue = DSAQueue()

for vertex in min_spanning_tree.depthFirstVisitedList(choice):
	vertex_queue.enqueue(np.array([vertex.getLabel(), 180])) # enqueue the vertex name AND the value 180
# 180 is the value assosciated with each vertex because it is the value in minutes (3 hours), that
# the campaigner(s) must spend at each electorate (and airports too for waiting + security checks, etc)

print()

# create an empty queue to store the (in-order of the dfs) edges
edge_queue = DSAQueue()

# once we have our list of visited vertices we need to find the edges 
# connecting them, this is done by taking each pair of vertices (i-1 & i) 
# i.e. 0,1 : 1,2 : 2,3 : etc,etc and using their combined labels as the
# key to the previously populated hash table... 
# ... as you might notice we are checking for the key-value or str(v1+v2)
# AND str(v2+v1), this is because of the previously discussed problem that 
# they're undirected edges, but only hashed with ONE of their combinations
# (on second thought, making the label of each edge a tuple with both label
# combinations would have been a much more elegant solution, oh well)

for i in range(1, len(min_spanning_tree.depthFirstVisitedList(choice))):
	v1 = min_spanning_tree.depthFirstVisitedList(choice)[i-1].value.getLabel() # the preceeding vertex in list
	v2 = min_spanning_tree.depthFirstVisitedList(choice)[i].value.getLabel() # the i-th vertex in the list
	real_edge = str(v1 + ' -> ' + v2) # good looking print-able output
	if str(v1+v2) in set(edge_list): # checking for FIRST combination
		edge_queue.enqueue(np.array([real_edge, edge_hash.get(str(v1+v2)).getValue().getValue()[1]])) # enqueue from -> to & TIME
	elif str(v2+v1) in set(edge_list): # checking for SECOND combination
		edge_queue.enqueue(np.array([real_edge, edge_hash.get(str(v2+v1)).getValue().getValue()[1]])) # enqueue from -> to & TIME

print()

# linked list for storing all the meet & greet + travel time values; iterable to find total time
total_time = DSALinkedList()

count = 0 # set a counter to 0
stop = len(vertex_queue) # we stop once we hit the last location
while not vertex_queue.isEmpty(): # until all the locations have been dealt with
	a_location = vertex_queue.dequeue() # look at location
	print(a_location) # print a location
	count += 1 # add to vertex counter
	total_time.insertLast(a_location[1]) # append location's time (180 mins) to the list
	if count == stop: # if stopping condition is met
		pass # exit
	else: # otherwise there must be another edge to add
		an_edge = edge_queue.dequeue() # look at edge
		print(an_edge) # print the edge
		total_time.insertLast(an_edge[1]) # append edge's travel time to the list

print()

# SOME electorates (Warringah, NSW; Capricornia, QLD; Flinders, VIC; Kennedy, QLD & Mayo, SA)
# don't actually have values for their edges (blame their Wikipedia coords being in the middle of ocean)...
# they're still included within the itinerary, but as we have no information for the travel time they
# of course CAN'T be factored into our total travel time - this means the estimated total travel time
# will be an UNDERESTIMATE of the true value if a 'NONE' edge exists in the campaign trail

# set has_none = True if a 'NONE' edge is found
has_none = False
for i in total_time:
	if i == 'NONE':
		has_none = True

if has_none == True: # if 'NONE' exists
	# warn user of the potential underestimate
	print("travel time doesn't exist for at least one edge")
	print("estimated total travel time is likely slightly underestimating real travel time")
else: # otherwise NO 'NONE's exist
	# so reassure user the estimate should be somewhat accurate!
	print("no NA's found in any edges")
	print("estimated total travel time should be an decent approximation of real travel time")

print()

print("ESTIMATED TOTAL TRAVEL TIME:")
travel_time = 0 # initiate total travel = 0 minutes
for i in total_time:
	if i != 'NONE':
		travel_time += int(i) # add the travel time to the total

print(travel_time, 'minutes') # minutes
print(int(travel_time / 60), 'hours', travel_time % 60, 'minutes') # hours, minutes
print(int(travel_time / 60 / 24), 'days', int(travel_time / 60) % 24, 'hours', travel_time % 60, 'minutes') # days, hour, minutes

print()