import numpy as np
import re

import sys
sys.path.append("../w2/")
from DSASorts import *
sys.path.append("../w4/")
from linkedLists import *
from DSAQueue import *
sys.path.append("../w6/")
from DSAGraph import *
sys.path.append("../w8/")
from DSAHash import *

from Processing import *
from Region import *


pp = Processing()

print()

# importing airport data csv
airport_data = pp.readCSV('./data/AirportDist1.0.csv', 2)
print(airport_data[0], 'BEFORE')

# converting airport data times from hh:mm:ss to mins
for i in airport_data:
	temp = re.findall('\d+(?=:)',i[9])
	i[9] = str((int(temp[0])*60) + int(temp[1]))

print(airport_data[0], 'AFTER')

print()

# importing electorate data csv
electorate_data = pp.readCSV('./data/ElectDist1.0.csv', 2)
print(electorate_data[0], 'BEFORE')

# getting km/h (unnecessary now but kept code because whatever)
# and converting the SECONDS into MINUTES (accidently labelled
# the data as minutes when it's actually seconds, oooooops)
km_h_list = DSALinkedList()
for i in electorate_data:
	if i[9] == 'NONE':
		pass
	else:
		i[9] = str(int(i[9]) // 60) # seconds to minutes conversion
		km_h_list.insertLast(int((int(i[8]) / 1000) // (int(i[9]) / 60))) # getting speed (km/h)

# finding the total km/h (again useless info at this point)
km_h = sum(km_h_list) / float(len(km_h_list))
print(km_h, 'km/h')

print(electorate_data[0], 'AFTER')

print()

# only taking the PLANE methods of travel from airport to airport
# because multiple edges to the same place wasn't quite supported
# in my Kruskal's algorithm, so I decided to make the assumption
# that the party campaigning likely has the money to pay for flights
# (and doesn't want to waste hours and hours driving across Australia)
airport_data_clean = DSALinkedList()
for z in airport_data:
	if z[10] == 'plane':
		airport_data_clean.insertLast(z)
# these are actually the routes necessary to get OUT of the ACT
# without these edges being included, it'd be impossible for
# an algorithm to exit ACT (would be disconnected graph)
airport_data_clean.insertLast(electorate_data[1]) 
airport_data_clean.insertLast(electorate_data[2])
airport_data_clean.insertLast(electorate_data[3])
airport_data_clean.insertLast(electorate_data[4])

# for i in airport_data_clean:
# 	print(i)

print()

print('deleting all elements with NONE distance and NONE time because they are useless for our purpose')
# i calculated average km/h and was going to find polar distance, to estimate time but 
# wikipedia coordinates were junk for the electorates with missing data (hence them missing)
for i in electorate_data:
	if i[9] == 'NONE':
		i = None
print()

# this was a MEL to SYD combination already had a flight value, so adding this
# by car option would cause problems for my algorithm so just deleted it for now
print('deleting the 5th elemenet (car route from MEL air to SYD air) because plane route already exists and it probably will cause problems')
electorate_data[5] = None
print('electorate_data[5] :', electorate_data[5])

print()
print('deleting the ACT driving routes from Canberra & Fenner to airports as they were attached to the new airport_data_clean array')

print(electorate_data[0:7], 'BEFORE')

# deleting these FOUR routes out of the ACT from the electorate data
# as they were already added to my airport data (made more sense)
electorate_data[1] = None
electorate_data[2] = None
electorate_data[3] = None
electorate_data[4] = None

print(electorate_data[0:7], 'AFTER')

pp.serialize('airport_dist_clean.pickle', airport_data_clean)
pp.serialize('electorate_dist_clean.pickle', electorate_data)


print()